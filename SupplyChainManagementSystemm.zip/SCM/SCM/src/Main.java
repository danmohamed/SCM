import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        SupplyChainManager scm = new SupplyChainManager();
        Scanner scanner = new Scanner(System.in);

        // Sample Data
        scm.addSupplier(new Supplier("S001", "Supplier A", "123-456-7890"));
        scm.addCategory(new RawMaterialCategory("C001", "Steel", "Raw steel for production", 100));
        scm.addCategory(new FinishedProductCategory("C002", "Widget", "Finished widget product", 50));

        while (true) {
            System.out.println("1. View Categories");
            System.out.println("2. View Suppliers");
            System.out.println("3. Place Order");
            System.out.println("4. Add Supplier");
            System.out.println("5. Add Raw Material Category");
            System.out.println("6. Add Finished Product Category");
            System.out.println("7. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character

            switch (choice) {
                case 1:
                    scm.viewCategories();
                    break;
                case 2:
                    scm.viewSuppliers();
                    break;
                case 3:
                    System.out.print("Enter supplier ID: ");
                    String supplierID = scanner.next();
                    System.out.print("Enter quantity: ");
                    int quantity = scanner.nextInt();
                    // Find supplier by ID
                    for (Supplier supplier : scm.getSuppliers()) {
                        if (supplier.getSupplierID().equals(supplierID)) {
                            scm.placeOrder(supplier, quantity);
                            break;
                        }
                    }
                    break;
                case 4:
                    System.out.print("Enter supplier ID: ");
                    String supplierID1 = scanner.next();
                    System.out.print("Enter supplier name: ");
                    String supplierName = scanner.next();
                    System.out.print("Enter supplier phone number: ");
                    String supplierPhone = scanner.next();
                    scm.addSupplier(new Supplier(supplierID1, supplierName, supplierPhone));
                    break;
                case 5:
                    // Adding Raw Material Category
                    System.out.print("Enter Category ID: ");
                    String rawCategoryID = scanner.nextLine();
                    System.out.print("Enter Name: ");
                    String rawName = scanner.nextLine();
                    System.out.print("Enter Description: ");
                    String rawDescription = scanner.nextLine();
                    System.out.print("Enter Available Quantity: ");
                    int rawQuantity = scanner.nextInt();
                    scm.addCategory(new RawMaterialCategory(rawCategoryID, rawName, rawDescription, rawQuantity));
                    System.out.println("Raw Material Category added.");
                    break;
                case 6:
                    // Adding Finished Product Category
                    System.out.print("Enter Category ID: ");
                    String finishedCategoryID = scanner.nextLine();
                    System.out.print("Enter Name: ");
                    String finishedName = scanner.nextLine();
                    System.out.print("Enter Description: ");
                    String finishedDescription = scanner.nextLine();
                    System.out.print("Enter Inventory Count: ");
                    int finishedInventoryCount = scanner.nextInt();
                    scm.addCategory(new FinishedProductCategory(finishedCategoryID, finishedName, finishedDescription, finishedInventoryCount));
                    System.out.println("Finished Product Category added.");
                    break;
                case 7:
                    System.out.println("Exiting...");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}