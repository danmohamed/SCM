class RawMaterialCategory extends ProductCategory {
    private int availableQuantity;

    public RawMaterialCategory(String categoryID, String name, String description, int availableQuantity) {
        super(categoryID, name, description);
        this.availableQuantity = availableQuantity;
    }

    public int getAvailableQuantity() {
        return availableQuantity;
    }

    public void setAvailableQuantity(int availableQuantity) {
        this.availableQuantity = availableQuantity;
    }

    public boolean checkAvailability() {
        return availableQuantity > 0;
    }

    @Override
    public void displayDetails() {
        System.out.println("Raw Material Category: " + getName() + ", Available: " + availableQuantity);
    }
}