class FinishedProductCategory extends ProductCategory {
    private int inventoryCount;

    public FinishedProductCategory(String categoryID, String name, String description, int inventoryCount) {
        super(categoryID, name, description);
        this.inventoryCount = inventoryCount;
    }

    public int getInventoryCount() {
        return inventoryCount;
    }

    public void setInventoryCount(int inventoryCount) {
        this.inventoryCount = inventoryCount;
    }

    public void trackInventory() {
        System.out.println("Inventory Count for " + getName() + ": " + inventoryCount);
    }

    @Override
    public void displayDetails() {
        System.out.println("Finished Product Category: " + getName() + ", Inventory Count: " + inventoryCount);
    }
}