import java.util.ArrayList;

class SupplyChainManager {
    private ArrayList<ProductCategory> categories = new ArrayList<>();
    private ArrayList<Supplier> suppliers = new ArrayList<>();

    public void addCategory(ProductCategory category) {
        categories.add(category);
    }

    public void viewCategories() {
        for (ProductCategory category : categories) {
            category.displayDetails();
        }
    }

    public void placeOrder(Supplier supplier, int quantity) {
        System.out.println("Order placed with " + supplier.getName() + " for quantity: " + quantity);
    }

    public void viewSuppliers() {
        for (Supplier supplier : suppliers) {
            System.out.println("Supplier ID: "+supplier.getSupplierID()+", Supplier: " + supplier.getName() + ", Contact: " + supplier.getContactInfo());
        }
    }

    public void addSupplier(Supplier supplier) {
        suppliers.add(supplier);
    }

    public ArrayList<Supplier> getSuppliers() {
        return suppliers;
    }
}